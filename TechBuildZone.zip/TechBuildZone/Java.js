document.body.innerHTML = ` 
<!-- =========================
     NAVIGATION
========================= -->
<header class="site-header">
    <nav class="navbar container">

        <!-- Logo -->
        <a href="#home" class="logo">
            <img src="../Img/TechBuildzone.png" height="40px" style="border-radius: 5px;">
            <span class="logo-text">Tech<span>Combinators</span></span>
        </a>

        <!-- Desktop Navigation -->
        <ul class="nav-links">
            <li>
                <a href="#home" class="nav-link active">Home</a>
            </li>
            <li>
                <a href="#services" class="nav-link">Services</a>
            </li>
            <li>
                <a href="#about" class="nav-link">About</a>
            </li>
            <li>
                <a href="#founder" class="nav-link">Founder</a>
            </li>
            <li>
                <a href="#payments" class="nav-link">Payments</a>
            </li>
            <li>
                <a href="#contact" class="nav-link">Contact</a>
            </li>
        </ul>

        <!-- Right Side -->
        <div class="nav-actions">
            <a href="#contact" class="nav-cta">
                Get Support
                <span>↗</span>
            </a>
        </div>

        <!-- Mobile Menu Button -->
        <button
            class="menu-toggle"
            id="menuToggle"
            aria-label="Open navigation menu"
            aria-expanded="false"
        >
            <span></span>
            <span></span>
            <span></span>
        </button>

    </nav>
</header>


<!-- =========================
     HERO SECTION
========================= -->
<section class="hero" id="home">

    <!-- Background Effects -->
    <div class="hero-bg-glow glow-one"></div>
    <div class="hero-bg-glow glow-two"></div>

    <div class="container hero-container">

        <!-- Hero Content -->
        <div class="hero-content">

            <!-- Badge -->
            <div class="hero-badge">
                <span class="status-dot"></span>
                Available 24/7 for IT Support
            </div>

            <!-- Heading -->
            <h1>
                Smart Technology.
                <span>Reliable Solutions.</span>
            </h1>

            <!-- Description -->
            <p class="hero-description">
                TechCombinators provides professional software development,
                IT support, networking, PC solutions, and technology services
                tailored to your needs.
            </p>

            <!-- Buttons -->
            <div class="hero-buttons">

                <a href="#contact" class="btn btn-primary">
                    Request a Service
                    <span>↗</span>
                </a>

                <a href="#services" class="btn btn-secondary">
                    Explore Services
                    <span>→</span>
                </a>

            </div>

            <!-- Trust Information -->
            <div class="hero-trust">

                <div class="trust-item">
                    <strong>24/7</strong>
                    <span>Support Available</span>
                </div>

                <div class="trust-divider"></div>

                <div class="trust-item">
                    <strong>LKR & USD</strong>
                    <span>Payment Options</span>
                </div>

                <div class="trust-divider"></div>

                <div class="trust-item">
                    <strong>IT</strong>
                    <span>Technical Solutions</span>
                </div>

            </div>

        </div>


        <!-- Hero Visual -->
        <div class="hero-visual">

            <div class="tech-card">

                <!-- Card Header -->
                <div class="tech-card-header">
                    <div class="window-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>

                    <span class="card-label">
                        TECHCOMBINATORS
                    </span>
                </div>

                <!-- Code / Technology Display -->
                <div class="tech-code">

                    <div class="code-line">
                        <span class="code-number">01</span>
                        <span class="code-blue">const</span>
                        <span class="code-white">solution</span>
                        <span class="code-gray">=</span>
                    </div>

                    <div class="code-line indent">
                        <span class="code-bracket">{</span>
                    </div>

                    <div class="code-line indent-more">
                        <span class="code-blue">service:</span>
                        <span class="code-green">
                            "Technology"
                        </span>
                    </div>

                    <div class="code-line indent-more">
                        <span class="code-blue">support:</span>
                        <span class="code-green">
                            "24/7"
                        </span>
                    </div>

                    <div class="code-line indent-more">
                        <span class="code-blue">payments:</span>
                        <span class="code-green">
                            ["LKR", "USD"]
                        </span>
                    </div>

                    <div class="code-line indent">
                        <span class="code-bracket">};</span>
                    </div>

                </div>

                <!-- Status -->
                <div class="tech-status">
                    <span class="status-dot"></span>
                    Systems Ready
                </div>

            </div>


            <!-- Floating Cards -->

            <div class="floating-card floating-card-one">
                <div class="floating-icon">
                    &lt;/&gt;
                </div>

                <div>
                    <strong>Web Apps</strong>
                    <span>Development</span>
                </div>
            </div>


            <div class="floating-card floating-card-two">
                <div class="floating-icon">
                    ⚙
                </div>

                <div>
                    <strong>IT Support</strong>
                    <span>Available 24/7</span>
                </div>
            </div>


            <div class="hero-orbit orbit-one"></div>
            <div class="hero-orbit orbit-two"></div>

        </div>

    </div>

    <!-- Scroll Indicator -->
    <a href="#services" class="scroll-indicator">
        <span></span>
        Scroll to explore
    </a>

</section>





<!-- =========================
     SERVICES SECTION
========================= -->
<section class="services-section" id="services">

    <div class="container">

        <!-- Section Header -->
        <div class="section-header">

            <div class="section-badge">
                <span></span>
                What We Do
            </div>

            <h2>
                Technology Services
                <span>Built Around You.</span>
            </h2>

            <p>
                From custom software to complete IT support, we provide
                practical technology solutions for individuals, startups,
                and businesses.
            </p>

        </div>


        <!-- Services Grid -->
        <div class="services-grid">

            <!-- Service 01 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">01</span>

                    <div class="service-icon">
                        &lt;/&gt;
                    </div>
                </div>

                <div class="service-content">

                    <h3>Web Application Development</h3>

                    <p>
                        Custom, responsive web applications designed
                        around your business requirements and workflow.
                    </p>

                    <ul class="service-features">
                        <li>Custom Web Applications</li>
                        <li>Business Management Systems</li>
                        <li>Responsive UI Development</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>


            <!-- Service 02 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">02</span>

                    <div class="service-icon">
                        C#
                    </div>
                </div>

                <div class="service-content">

                    <h3>Windows Application Development</h3>

                    <p>
                        Professional Windows desktop applications
                        developed using C# and modern .NET technologies.
                    </p>

                    <ul class="service-features">
                        <li>C# / .NET Applications</li>
                        <li>Desktop Business Software</li>
                        <li>Custom Automation Solutions</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>


            <!-- Service 03 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">03</span>

                    <div class="service-icon">
                        ◉
                    </div>
                </div>

                <div class="service-content">

                    <h3>Network Troubleshooting</h3>

                    <p>
                        Diagnose and resolve network connectivity,
                        LAN, Wi-Fi, and configuration-related problems.
                    </p>

                    <ul class="service-features">
                        <li>Network Diagnostics</li>
                        <li>LAN / Wi-Fi Troubleshooting</li>
                        <li>Connectivity Issues</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>


            <!-- Service 04 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">04</span>

                    <div class="service-icon">
                        PC
                    </div>
                </div>

                <div class="service-content">

                    <h3>PC Building</h3>

                    <p>
                        Build and configure PCs based on your performance,
                        budget, gaming, business, or workstation requirements.
                    </p>

                    <ul class="service-features">
                        <li>Custom PC Builds</li>
                        <li>Component Selection</li>
                        <li>Installation & Configuration</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>


            <!-- Service 05 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">05</span>

                    <div class="service-icon">
                        ⚙
                    </div>
                </div>

                <div class="service-content">

                    <h3>Router Configuration</h3>

                    <p>
                        Configure routers and wireless networks for
                        reliable connectivity and appropriate security.
                    </p>

                    <ul class="service-features">
                        <li>Router Setup</li>
                        <li>Wi-Fi Configuration</li>
                        <li>Network Configuration</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>


            <!-- Service 06 -->
            <article class="service-card">

                <div class="service-top">
                    <span class="service-number">06</span>

                    <div class="service-icon">
                        ?
                    </div>
                </div>

                <div class="service-content">

                    <h3>IT Help Desk</h3>

                    <p>
                        Technical assistance for everyday software,
                        hardware, configuration, and IT-related issues.
                    </p>

                    <ul class="service-features">
                        <li>Technical Support</li>
                        <li>Software Assistance</li>
                        <li>Remote Troubleshooting</li>
                    </ul>

                </div>

                <a href="#contact" class="service-link">
                    Request Service
                    <span>↗</span>
                </a>

            </article>

        </div>


        <!-- Bottom CTA -->
        <div class="services-cta">

            <div class="services-cta-content">

                <div class="cta-icon">
                    +
                </div>

                <div>
                    <h3>Need a Custom Technology Solution?</h3>

                    <p>
                        Tell us what you need and we'll discuss
                        the right solution for your requirements.
                    </p>
                </div>

            </div>

            <a href="#contact" class="services-cta-button">
                Talk to Us
                <span>↗</span>
            </a>

        </div>

    </div>

</section>








<!-- =========================
     ABOUT TECHCOMBINATORS
========================= -->
<section class="about-section" id="about">

    <div class="container">

        <div class="about-grid">

            <!-- Left Content -->
            <div class="about-content">

                <div class="section-badge">
                    <span></span>
                    About TechCombinators
                </div>

                <h2>
                    Technology That
                    <span>Works For You.</span>
                </h2>

                <p class="about-lead">
                    TechCombinators is a technology and IT services
                    company focused on providing practical, reliable,
                    and customized solutions for customers.
                </p>

                <p class="about-text">
                    From developing modern web applications and
                    Windows software to troubleshooting networks,
                    building PCs, configuring routers, and providing
                    IT support, we help customers solve their
                    technology challenges with solutions tailored
                    to their requirements.
                </p>

                <div class="about-buttons">

                    <a href="#services" class="about-btn primary">
                        Explore Our Services
                        <span>→</span>
                    </a>

                    <a href="#contact" class="about-btn secondary">
                        Contact Us
                        <span>↗</span>
                    </a>

                </div>

            </div>


            <!-- Right Content -->
            <div class="about-visual">

                <!-- Main Card -->
                <div class="about-main-card">

                    <div class="about-card-header">

                        <div class="about-logo">
                            &lt;/&gt;
                        </div>

                        <div>
                            <span class="about-card-label">
                                TECHCOMBINATORS
                            </span>

                            <strong>
                                Technology Solutions
                            </strong>
                        </div>

                    </div>


                    <!-- Solution Flow -->
                    <div class="solution-flow">

                        <div class="solution-item">
                            <div class="solution-icon">
                                &lt;/&gt;
                            </div>

                            <div>
                                <strong>Build</strong>
                                <span>Software & Apps</span>
                            </div>
                        </div>


                        <div class="solution-line"></div>


                        <div class="solution-item">
                            <div class="solution-icon">
                                ⚙
                            </div>

                            <div>
                                <strong>Configure</strong>
                                <span>IT & Networks</span>
                            </div>
                        </div>


                        <div class="solution-line"></div>


                        <div class="solution-item">
                            <div class="solution-icon">
                                ✓
                            </div>

                            <div>
                                <strong>Support</strong>
                                <span>24/7 Assistance</span>
                            </div>
                        </div>

                    </div>


                    <!-- Card Footer -->
                    <div class="about-card-footer">

                        <span>
                            <i></i>
                            Available 24/7
                        </span>

                        <span>
                            LKR / USD
                        </span>

                    </div>

                </div>


                <!-- Small Stats -->
                <div class="about-stat stat-one">

                    <strong>24/7</strong>

                    <span>
                        Support
                    </span>

                </div>


                <div class="about-stat stat-two">

                    <strong>2+</strong>

                    <span>
                        Payment Currencies
                    </span>

                </div>


                <!-- Decorative Circle -->
                <div class="about-circle"></div>

            </div>

        </div>


        <!-- Values -->
        <div class="about-values">

            <div class="value-card">

                <div class="value-icon">
                    ◈
                </div>

                <div>
                    <h3>Customer Focused</h3>

                    <p>
                        Solutions are designed around the
                        customer's specific requirements.
                    </p>
                </div>

            </div>


            <div class="value-card">

                <div class="value-icon">
                    ✓
                </div>

                <div>
                    <h3>Practical Solutions</h3>

                    <p>
                        We focus on useful technology that
                        solves real-world problems.
                    </p>
                </div>

            </div>


            <div class="value-card">

                <div class="value-icon">
                    ⚡
                </div>

                <div>
                    <h3>Fast Support</h3>

                    <p>
                        Technical assistance is available
                        around the clock.
                    </p>
                </div>

            </div>

        </div>

    </div>

</section>







<!-- =========================
     FOUNDER SECTION
========================= -->
<section class="founder-section" id="founder">

    <div class="container">

        <!-- Section Header -->
        <div class="section-header founder-header">

            <div class="section-badge">
                <span></span>
                The Founder
            </div>

            <h2>
                Behind
                <span>TechCombinators.</span>
            </h2>

            <p>
                Meet the person behind TechCombinators and the vision
                driving our technology and IT services.
            </p>

        </div>


        <!-- Founder Content -->
        <div class="founder-card">

            <!-- Founder Image -->
            <div class="founder-image-area">

                <div class="founder-image-frame">

                    <!-- Replace founder.jpg with the actual photo -->
                    <img
                        src="assets/images/founder.jpg"
                        alt="Founder of TechCombinators"
                    >

                    <div class="founder-image-overlay"></div>

                    <div class="founder-image-label">
                        <span class="status-dot"></span>
                        TechCombinators
                    </div>

                </div>

                <!-- Decorative elements -->
                <div class="founder-orbit orbit-founder-one"></div>
                <div class="founder-orbit orbit-founder-two"></div>

            </div>


            <!-- Founder Information -->
            <div class="founder-content">

                <span class="founder-role">
                    Founder & Technology Lead
                </span>

                <!-- Replace with actual founder name -->
                <h3>
                    [Founder Name]
                </h3>

                <div class="founder-line"></div>

                <p class="founder-intro">
                    TechCombinators was founded with a focus on making
                    technology solutions more practical, accessible,
                    and useful for customers.
                </p>

                <p class="founder-description">
                    With an interest in software development, IT systems,
                    networking, and technology, the founder leads
                    TechCombinators with a customer-focused approach.
                    The goal is to understand each customer's requirements
                    and provide a solution that fits their needs.
                </p>


                <!-- Founder Expertise -->
                <div class="founder-expertise">

                    <div class="expertise-item">
                        <span class="expertise-icon">&lt;/&gt;</span>
                        <div>
                            <strong>Software</strong>
                            <small>Development</small>
                        </div>
                    </div>

                    <div class="expertise-item">
                        <span class="expertise-icon">⚙</span>
                        <div>
                            <strong>IT</strong>
                            <small>Solutions</small>
                        </div>
                    </div>

                    <div class="expertise-item">
                        <span class="expertise-icon">◉</span>
                        <div>
                            <strong>Networks</strong>
                            <small>Configuration</small>
                        </div>
                    </div>

                    <div class="expertise-item">
                        <span class="expertise-icon">?</span>
                        <div>
                            <strong>Support</strong>
                            <small>24/7 Assistance</small>
                        </div>
                    </div>

                </div>


                <!-- Founder Quote -->
                <div class="founder-quote">

                    <span class="quote-mark">“</span>

                    <p>
                        Technology should solve problems, simplify
                        work, and create practical value.
                    </p>

                </div>

            </div>

        </div>


        <!-- Founder Bottom Message -->
        <div class="founder-bottom">

            <div class="founder-bottom-icon">
                ✓
            </div>

            <div>
                <strong>
                    Building solutions with purpose.
                </strong>

                <span>
                    From software development to everyday IT support.
                </span>
            </div>

        </div>

    </div>

</section>








<!-- =========================
     PAYMENT SECTION
========================= -->
<section class="payment-section" id="payments">

    <div class="container">

        <!-- Section Header -->
        <div class="section-header payment-header">

            <div class="section-badge">
                <span></span>
                Payments & Policies
            </div>

            <h2>
                Simple & Flexible
                <span>Payment Options.</span>
            </h2>

            <p>
                TechCombinators accepts payments in both Sri Lankan
                Rupees and US Dollars for our technology and IT services.
            </p>

        </div>


        <!-- Payment Cards -->
        <div class="payment-grid">

            <!-- LKR -->
            <div class="payment-card">

                <div class="payment-card-top">

                    <div class="currency-icon">
                        Rs
                    </div>

                    <span class="currency-code">
                        LKR
                    </span>

                </div>

                <div class="payment-card-content">

                    <span class="currency-label">
                        Sri Lankan Rupee
                    </span>

                    <h3>
                        LKR Payments
                    </h3>

                    <p>
                        Pay for services using Sri Lankan Rupees.
                        Payment instructions will be provided when
                        your service request is confirmed.
                    </p>

                </div>

                <div class="payment-status">
                    <span></span>
                    Available
                </div>

            </div>


            <!-- USD -->
            <div class="payment-card payment-card-featured">

                <div class="payment-card-top">

                    <div class="currency-icon">
                        $
                    </div>

                    <span class="currency-code">
                        USD
                    </span>

                </div>

                <div class="payment-card-content">

                    <span class="currency-label">
                        United States Dollar
                    </span>

                    <h3>
                        USD Payments
                    </h3>

                    <p>
                        International customers can make payments
                        in US Dollars. Payment instructions will be
                        provided after service confirmation.
                    </p>

                </div>

                <div class="payment-status">
                    <span></span>
                    Available
                </div>

            </div>

        </div>


        <!-- Payment Process -->
        <div class="payment-process">

            <div class="process-item">

                <div class="process-number">
                    01
                </div>

                <div>
                    <strong>Request</strong>
                    <span>Tell us what you need.</span>
                </div>

            </div>


            <div class="process-line"></div>


            <div class="process-item">

                <div class="process-number">
                    02
                </div>

                <div>
                    <strong>Confirm</strong>
                    <span>Review the service and price.</span>
                </div>

            </div>


            <div class="process-line"></div>


            <div class="process-item">

                <div class="process-number">
                    03
                </div>

                <div>
                    <strong>Pay</strong>
                    <span>Complete your payment.</span>
                </div>

            </div>


            <div class="process-line"></div>


            <div class="process-item">

                <div class="process-number">
                    04
                </div>

                <div>
                    <strong>Start</strong>
                    <span>We begin the agreed service.</span>
                </div>

            </div>

        </div>


        <!-- No Refund Policy -->
        <div class="refund-policy">

            <div class="refund-icon">
                !
            </div>

            <div class="refund-content">

                <div class="refund-title">
                    <span>Important Payment Policy</span>
                    <strong>No Refund Policy</strong>
                </div>

                <p>
                    Payments made for confirmed services are
                    <strong>non-refundable</strong>. Please review
                    the service requirements, scope, and agreed
                    price carefully before making payment.
                </p>

                <p class="refund-note">
                    By proceeding with payment, the customer
                    acknowledges and agrees to the applicable
                    service and payment terms.
                </p>

            </div>

        </div>


        <!-- CTA -->
        <div class="payment-cta">

            <div>
                <strong>
                    Ready to request a service?
                </strong>

                <span>
                    Contact TechCombinators to discuss your requirements.
                </span>
            </div>

            <a href="#contact" class="payment-cta-button">
                Contact Us
                <span>↗</span>
            </a>

        </div>

    </div>

</section>






<!-- =========================
     CONTACT SECTION
========================= -->
<section class="contact-section" id="contact">

    <div class="container">

        <!-- Header -->
        <div class="section-header contact-header">

            <div class="section-badge">
                <span></span>
                Get In Touch
            </div>

            <h2>
                Let's Solve Your
                <span>Technology Needs.</span>
            </h2>

            <p>
                Need a website, desktop application, network support,
                PC build, or IT assistance? Contact TechCombinators
                and tell us what you need.
            </p>

        </div>


        <div class="contact-grid">

            <!-- Contact Information -->
            <div class="contact-info">

                <div class="contact-info-header">
                    <span>Contact TechCombinators</span>

                    <h3>
                        We're here to help.
                    </h3>

                    <p>
                        Choose your preferred way to contact us.
                        For service requests, you can also submit
                        the Google Form.
                    </p>
                </div>


                <!-- Mobile -->
                <a
                    href="tel:+947XXXXXXXX"
                    class="contact-item"
                >

                    <div class="contact-icon">
                        ☎
                    </div>

                    <div class="contact-item-content">

                        <span>
                            Mobile
                        </span>

                        <strong>
                            +94 7X XXX XXXX
                        </strong>

                        <small>
                            Call or contact us directly
                        </small>

                    </div>

                    <span class="contact-arrow">
                        ↗
                    </span>

                </a>


                <!-- Email -->
                <a
                    href="mailto:your-email@example.com"
                    class="contact-item"
                >

                    <div class="contact-icon">
                        @
                    </div>

                    <div class="contact-item-content">

                        <span>
                            Email
                        </span>

                        <strong>
                            your-email@example.com
                        </strong>

                        <small>
                            Send us your requirements
                        </small>

                    </div>

                    <span class="contact-arrow">
                        ↗
                    </span>

                </a>


                <!-- Google Form -->
                <a
                    href="https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="contact-item contact-form-item"
                >

                    <div class="contact-icon form-icon">
                        ✓
                    </div>

                    <div class="contact-item-content">

                        <span>
                            Service Request
                        </span>

                        <strong>
                            Google Form
                        </strong>

                        <small>
                            Submit your project or support request
                        </small>

                    </div>

                    <span class="contact-arrow">
                        ↗
                    </span>

                </a>

            </div>


            <!-- Contact CTA -->
            <div class="contact-card">

                <div class="contact-card-glow"></div>

                <div class="contact-card-content">

                    <div class="contact-card-icon">
                        &lt;/&gt;
                    </div>

                    <span class="contact-card-label">
                        TECHCOMBINATORS
                    </span>

                    <h3>
                        Have a technology
                        <span>problem?</span>
                    </h3>

                    <p>
                        Tell us about your requirement and we'll
                        help you identify the right technology
                        solution.
                    </p>


                    <!-- Availability -->
                    <div class="availability">

                        <span class="availability-dot"></span>

                        <div>
                            <strong>
                                Available 24/7
                            </strong>

                            <small>
                                IT support & service requests
                            </small>
                        </div>

                    </div>


                    <!-- Google Form Button -->
                    <a
                        href="https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="contact-main-button"
                    >
                        Submit Service Request
                        <span>↗</span>
                    </a>


                    <span class="contact-response">
                        We'll review your request and get in touch.
                    </span>

                </div>

            </div>

        </div>


        <!-- Bottom Contact Strip -->
        <div class="contact-bottom">

            <div>
                <span class="bottom-label">
                    PAYMENT
                </span>

                <strong>
                    LKR / USD
                </strong>
            </div>

            <div class="bottom-divider"></div>

            <div>
                <span class="bottom-label">
                    AVAILABILITY
                </span>

                <strong>
                    24 / 7
                </strong>
            </div>

            <div class="bottom-divider"></div>

            <div>
                <span class="bottom-label">
                    SERVICE
                </span>

                <strong>
                    IT & Software Solutions
                </strong>
            </div>

        </div>

    </div>

</section>






<!-- =========================
     FOOTER
========================= -->
<footer class="site-footer">

    <div class="container">

        <!-- Footer Main -->
        <div class="footer-main">

            <!-- Brand -->
            <div class="footer-brand">

                <a href="#home" class="footer-logo">
                    <span class="footer-logo-icon">
                        &lt;/&gt;
                    </span>

                    <span>
                        Tech<span>Combinators</span>
                    </span>
                </a>

                <p>
                    Technology and IT solutions designed to help
                    customers build, configure, troubleshoot,
                    and manage their technology.
                </p>

                <div class="footer-availability">
                    <span></span>
                    Available 24/7
                </div>

            </div>


            <!-- Quick Links -->
            <div class="footer-column">

                <h3>Quick Links</h3>

                <ul>
                    <li>
                        <a href="#home">Home</a>
                    </li>

                    <li>
                        <a href="#about">About</a>
                    </li>

                    <li>
                        <a href="#services">Services</a>
                    </li>

                    <li>
                        <a href="#founder">Founder</a>
                    </li>

                    <li>
                        <a href="#payments">Payments</a>
                    </li>

                    <li>
                        <a href="#contact">Contact</a>
                    </li>
                </ul>

            </div>


            <!-- Services -->
            <div class="footer-column">

                <h3>Services</h3>

                <ul>
                    <li>
                        <a href="#services">
                            Web Applications
                        </a>
                    </li>

                    <li>
                        <a href="#services">
                            Windows Applications
                        </a>
                    </li>

                    <li>
                        <a href="#services">
                            Network Troubleshooting
                        </a>
                    </li>

                    <li>
                        <a href="#services">
                            PC Building
                        </a>
                    </li>

                    <li>
                        <a href="#services">
                            Router Configuration
                        </a>
                    </li>

                    <li>
                        <a href="#services">
                            IT Help Desk
                        </a>
                    </li>
                </ul>

            </div>


            <!-- Contact -->
            <div class="footer-column footer-contact">

                <h3>Contact</h3>

                <a href="tel:+947XXXXXXXX">
                    <span class="footer-contact-icon">
                        ☎
                    </span>

                    <span>
                        +94 7X XXX XXXX
                    </span>
                </a>

                <a href="mailto:your-email@example.com">
                    <span class="footer-contact-icon">
                        @
                    </span>

                    <span>
                        your-email@example.com
                    </span>
                </a>

                <a
                    href="https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <span class="footer-contact-icon">
                        ✓
                    </span>

                    <span>
                        Submit Service Request
                    </span>
                </a>

            </div>

        </div>


        <!-- Footer Highlight -->
        <div class="footer-highlight">

            <div class="footer-highlight-item">

                <span class="highlight-icon">
                    Rs
                </span>

                <div>
                    <strong>LKR</strong>
                    <small>Local Payments</small>
                </div>

            </div>


            <div class="footer-highlight-item">

                <span class="highlight-icon">
                    $
                </span>

                <div>
                    <strong>USD</strong>
                    <small>International Payments</small>
                </div>

            </div>


            <div class="footer-highlight-item">

                <span class="highlight-icon green">
                    ✓
                </span>

                <div>
                    <strong>24/7</strong>
                    <small>Available for Support</small>
                </div>

            </div>


            <div class="footer-highlight-item">

                <span class="highlight-icon warning">
                    !
                </span>

                <div>
                    <strong>No Refund</strong>
                    <small>Payment Policy Applies</small>
                </div>

            </div>

        </div>


        <!-- Footer Bottom -->
        <div class="footer-bottom">

            <p>
                © <span id="currentYear"></span>
                TechCombinators.
                All rights reserved.
            </p>

            <div class="footer-legal">

                <a href="#payments">
                    Payment Policy
                </a>

                <span>•</span>

                <a href="#contact">
                    Contact
                </a>

            </div>

        </div>

    </div>

</footer>



<style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* =========================
   NAVIGATION
========================= */

.site-header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;

    background: rgba(5, 11, 24, 0.88);
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);

    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
}

.container {
    width: min(1200px, 92%);
    margin: 0 auto;
}

.navbar {
    height: 76px;

    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 30px;
}

/* =========================
   LOGO
========================= */

.logo {
    display: flex;
    align-items: center;
    gap: 10px;

    color: #ffffff;
    text-decoration: none;

    font-size: 20px;
    font-weight: 700;
    white-space: nowrap;
}

.logo-mark {
    width: 38px;
    height: 38px;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #ffffff;
    background: linear-gradient(
        135deg,
        #0049af,
        #002f58
    );

    border-radius: 10px;

    font-size: 16px;
    font-weight: 800;

    box-shadow: 0 0 25px rgba(22, 119, 255, 0.3);
}

.logo-text span {
    color: #38a3ff;
}

/* =========================
   NAV LINKS
========================= */

.nav-links {
    display: flex;
    align-items: center;
    gap: 32px;

    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-link {
    position: relative;

    color: #9fb0c8;
    text-decoration: none;

    font-size: 14px;
    font-weight: 500;

    transition:
        color 0.3s ease,
        transform 0.3s ease;
}

.nav-link:hover {
    color: #ffffff;
}

.nav-link.active {
    color: #ffffff;
}

.nav-link.active::after {
    content: "";

    position: absolute;
    left: 0;
    bottom: -9px;

    width: 100%;
    height: 2px;

    background: #1677ff;
    border-radius: 10px;

    box-shadow: 0 0 10px rgba(22, 119, 255, 0.7);
}

/* =========================
   CTA
========================= */

.nav-actions {
    display: flex;
    align-items: center;
}

.nav-cta {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 11px 18px;

    color: #ffffff;
    background: #1677ff;

    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 9px;

    text-decoration: none;

    font-size: 14px;
    font-weight: 600;

    transition:
        background 0.3s ease,
        transform 0.3s ease,
        box-shadow 0.3s ease;
}

.nav-cta span {
    font-size: 16px;
    transition: transform 0.3s ease;
}

.nav-cta:hover {
    background: #0868e8;

    transform: translateY(-2px);

    box-shadow:
        0 8px 25px rgba(22, 119, 255, 0.3);
}

.nav-cta:hover span {
    transform: translate(2px, -2px);
}

/* =========================
   MOBILE MENU BUTTON
========================= */

.menu-toggle {
    display: none;

    width: 42px;
    height: 42px;

    padding: 8px;

    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 9px;

    cursor: pointer;
}

.menu-toggle span {
    display: block;

    width: 100%;
    height: 2px;

    margin: 5px 0;

    background: #ffffff;
    border-radius: 5px;

    transition: 0.3s ease;
}

/* =========================
   RESPONSIVE
========================= */

@media (max-width: 900px) {

    .nav-links {
        position: absolute;

        top: 80px;
        width: 80%;
        padding: 20px;

        flex-direction: column;
        align-items: flex-start;
        gap: 0;

        background: rgba(11, 22, 48, 0.98);

        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;

        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.35);

        opacity: 0;
        visibility: hidden;
        transform: translateY(-10px);

        transition:
            opacity 0.3s ease,
            visibility 0.3s ease,
            transform 0.3s ease;
    }

    .nav-links.active {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
    }

    .nav-links li {
        width: 100%;
    }

    .nav-link {
        display: block;
        width: 100%;
        padding: 14px 5px;
    }

    .nav-link.active::after {
        display: none;
    }

    .nav-actions {
        margin-left: auto;
    }

    .menu-toggle {
        display: block;
    }
}

@media (max-width: 600px) {

    .navbar {
        height: 68px;
    }

    .logo {
        font-size: 17px;
    }

    .logo-mark {
        width: 34px;
        height: 34px;
        font-size: 14px;
    }

    .nav-actions {
        display: none;
    }

    .nav-links {
        top: 68px;
    }
}










/* =========================
   HERO SECTION
========================= */

.hero {
    position: relative;

    min-height: 100vh;
    padding-top: 76px;

    display: flex;
    align-items: center;

    overflow: hidden;

    background:
        radial-gradient(
            circle at 80% 40%,
            rgba(22, 119, 255, 0.12),
            transparent 35%
        ),
        #050b18;
}


/* =========================
   BACKGROUND GLOWS
========================= */

.hero-bg-glow {
    position: absolute;

    width: 500px;
    height: 500px;

    border-radius: 50%;

    filter: blur(100px);

    pointer-events: none;
}

.glow-one {
    top: 5%;
    right: -200px;

    background: rgba(22, 119, 255, 0.12);
}

.glow-two {
    bottom: -250px;
    left: -200px;

    background: rgba(56, 163, 255, 0.08);
}


/* =========================
   HERO CONTAINER
========================= */

.hero-container {
    position: relative;
    z-index: 2;

    width: min(1200px, 92%);
    margin: 0 auto;

    display: grid;
    grid-template-columns: 1.05fr 0.95fr;

    align-items: center;

    gap: 70px;

    padding: 80px 0;
}


/* =========================
   HERO CONTENT
========================= */

.hero-content {
    max-width: 650px;
}


/* Badge */

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 9px;

    padding: 8px 14px;

    color: #b9c9df;

    background: rgba(22, 119, 255, 0.08);

    border: 1px solid rgba(56, 163, 255, 0.18);

    border-radius: 50px;

    font-size: 13px;
    font-weight: 500;

    margin-bottom: 25px;
}

.status-dot {
    width: 8px;
    height: 8px;

    display: inline-block;

    border-radius: 50%;

    background: #27e28b;

    box-shadow:
        0 0 0 4px rgba(39, 226, 139, 0.1),
        0 0 12px rgba(39, 226, 139, 0.7);
}


/* Heading */

.hero h1 {
    margin: 0;

    color: #ffffff;

    font-size: clamp(48px, 6vw, 78px);

    line-height: 1.04;

    letter-spacing: -3px;

    font-weight: 800;
}

.hero h1 span {
    display: block;

    background:
        linear-gradient(
            90deg,
            #1677ff,
            #38a3ff
        );

    -webkit-background-clip: text;
    background-clip: text;

    -webkit-text-fill-color: transparent;
}


/* Description */

.hero-description {
    max-width: 590px;

    margin: 28px 0 35px;

    color: #9fb0c8;

    font-size: 17px;
    line-height: 1.8;
}


/* =========================
   HERO BUTTONS
========================= */

.hero-buttons {
    display: flex;
    align-items: center;
    gap: 14px;

    flex-wrap: wrap;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;

    min-height: 50px;

    padding: 0 22px;

    border-radius: 9px;

    text-decoration: none;

    font-size: 14px;
    font-weight: 600;

    transition:
        transform 0.3s ease,
        box-shadow 0.3s ease,
        background 0.3s ease;
}

.btn span {
    font-size: 17px;
}


/* Primary */

.btn-primary {
    color: #ffffff;

    background: linear-gradient(
        135deg,
        #1677ff,
        #0868e8
    );

    box-shadow:
        0 10px 30px rgba(22, 119, 255, 0.2);
}

.btn-primary:hover {
    transform: translateY(-3px);

    box-shadow:
        0 15px 35px rgba(22, 119, 255, 0.35);
}


/* Secondary */

.btn-secondary {
    color: #d8e4f5;

    background: rgba(255, 255, 255, 0.035);

    border: 1px solid rgba(255, 255, 255, 0.1);
}

.btn-secondary:hover {
    color: #ffffff;

    background: rgba(255, 255, 255, 0.07);

    transform: translateY(-3px);
}


/* =========================
   TRUST INFO
========================= */

.hero-trust {
    display: flex;
    align-items: center;

    margin-top: 55px;

    gap: 25px;
}

.trust-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.trust-item strong {
    color: #ffffff;

    font-size: 16px;
    font-weight: 700;
}

.trust-item span {
    color: #70839e;

    font-size: 11px;
}

.trust-divider {
    width: 1px;
    height: 32px;

    background: rgba(255, 255, 255, 0.1);
}


/* =========================
   HERO VISUAL
========================= */

.hero-visual {
    position: relative;

    min-height: 500px;

    display: flex;
    align-items: center;
    justify-content: center;
}


/* =========================
   MAIN TECH CARD
========================= */

.tech-card {
    position: relative;
    z-index: 3;

    width: min(430px, 90%);

    padding: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(20, 38, 70, 0.95),
            rgba(8, 18, 38, 0.95)
        );

    border: 1px solid rgba(90, 150, 255, 0.16);

    border-radius: 18px;

    box-shadow:
        0 35px 80px rgba(0, 0, 0, 0.45),
        0 0 60px rgba(22, 119, 255, 0.08);

    backdrop-filter: blur(20px);

    animation: cardFloat 6s ease-in-out infinite;
}


/* Card Header */

.tech-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding-bottom: 16px;

    border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}

.window-dots {
    display: flex;
    gap: 6px;
}

.window-dots span {
    width: 8px;
    height: 8px;

    border-radius: 50%;

    background: #31445f;
}

.window-dots span:first-child {
    background: #ff5f57;
}

.window-dots span:nth-child(2) {
    background: #ffbd2e;
}

.window-dots span:nth-child(3) {
    background: #28c840;
}

.card-label {
    color: #607895;

    font-size: 9px;
    letter-spacing: 1.5px;
    font-weight: 600;
}


/* =========================
   CODE DISPLAY
========================= */

.tech-code {
    padding: 30px 10px;

    font-family:
        "Courier New",
        monospace;

    font-size: 14px;

    line-height: 2;
}

.code-line {
    display: flex;
    gap: 12px;
}

.code-number {
    width: 20px;

    color: #3b506c;

    user-select: none;
}

.code-blue {
    color: #4da3ff;
}

.code-white {
    color: #e8f1ff;
}

.code-gray {
    color: #7185a1;
}

.code-green {
    color: #36d993;
}

.code-bracket {
    color: #8094b0;
}

.indent {
    padding-left: 32px;
}

.indent-more {
    padding-left: 55px;
}


/* =========================
   SYSTEM STATUS
========================= */

.tech-status {
    display: flex;
    align-items: center;
    gap: 10px;

    padding: 12px 14px;

    color: #91a5c0;

    background: rgba(39, 226, 139, 0.04);

    border: 1px solid rgba(39, 226, 139, 0.08);

    border-radius: 9px;

    font-size: 11px;
}


/* =========================
   FLOATING CARDS
========================= */

.floating-card {
    position: absolute;
    z-index: 5;

    display: flex;
    align-items: center;
    gap: 11px;

    padding: 12px 15px;

    background: rgba(13, 27, 52, 0.9);

    border: 1px solid rgba(255, 255, 255, 0.08);

    border-radius: 12px;

    box-shadow:
        0 15px 35px rgba(0, 0, 0, 0.3);

    backdrop-filter: blur(12px);

    animation: floatingCard 5s ease-in-out infinite;
}

.floating-card strong {
    display: block;

    color: #ffffff;

    font-size: 11px;
}

.floating-card span {
    display: block;

    margin-top: 3px;

    color: #7185a1;

    font-size: 9px;
}

.floating-icon {
    width: 32px;
    height: 32px;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background: rgba(22, 119, 255, 0.1);

    border-radius: 8px;

    font-size: 13px;
}

.floating-card-one {
    top: 65px;
    left: 0;
}

.floating-card-two {
    right: 0;
    bottom: 65px;

    animation-delay: -2s;
}


/* =========================
   ORBITS
========================= */

.hero-orbit {
    position: absolute;

    border: 1px solid rgba(56, 163, 255, 0.08);

    border-radius: 50%;

    pointer-events: none;
}

.orbit-one {
    width: 500px;
    height: 500px;

    transform: rotate(25deg);
}

.orbit-two {
    width: 650px;
    height: 300px;

    transform: rotate(-30deg);
}


/* =========================
   SCROLL INDICATOR
========================= */

.scroll-indicator {
    position: absolute;

    bottom: 25px;
    left: 50%;

    transform: translateX(-50%);

    display: flex;
    align-items: center;
    gap: 10px;

    color: #607895;

    text-decoration: none;

    font-size: 10px;
    letter-spacing: 1px;

    text-transform: uppercase;
}

.scroll-indicator span {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #1677ff;

    box-shadow: 0 0 12px #1677ff;

    animation: scrollPulse 1.8s infinite;
}


/* =========================
   ANIMATIONS
========================= */

@keyframes cardFloat {

    0%,
    100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-10px);
    }
}

@keyframes floatingCard {

    0%,
    100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-8px);
    }
}

@keyframes scrollPulse {

    0% {
        opacity: 0.3;
        transform: translateY(0);
    }

    50% {
        opacity: 1;
        transform: translateY(5px);
    }

    100% {
        opacity: 0.3;
        transform: translateY(0);
    }
}


/* =========================
   TABLET
========================= */

@media (max-width: 950px) {

    .hero-container {
        grid-template-columns: 1fr;

        text-align: center;

        gap: 30px;
    }

    .hero-content {
        max-width: 700px;
        margin: 0 auto;
    }

    .hero-badge {
        margin-bottom: 20px;
    }

    .hero-description {
        margin-left: auto;
        margin-right: auto;
    }

    .hero-buttons {
        justify-content: center;
    }

    .hero-trust {
        justify-content: center;
    }

    .hero-visual {
        min-height: 450px;
    }
}


/* =========================
   MOBILE
========================= */

@media (max-width: 600px) {

    .hero {
        min-height: auto;
        padding-top: 68px;
    }

    .hero-container {
        padding: 70px 0 100px;
    }

    .hero h1 {
        font-size: 45px;
        letter-spacing: -2px;
    }

    .hero-description {
        font-size: 15px;
        line-height: 1.7;
    }

    .hero-buttons {
        flex-direction: column;
        width: 100%;
    }

    .btn {
        width: 100%;
    }

    .hero-trust {
        gap: 12px;
    }

    .trust-item strong {
        font-size: 13px;
    }

    .trust-item span {
        font-size: 9px;
    }

    .trust-divider {
        height: 25px;
    }

    .hero-visual {
        min-height: 400px;
    }

    .tech-card {
        width: 100%;
    }

    .floating-card-one {
        left: -5px;
        top: 35px;
    }

    .floating-card-two {
        right: -5px;
        bottom: 35px;
    }

    .orbit-one {
        width: 350px;
        height: 350px;
    }

    .orbit-two {
        width: 400px;
        height: 220px;
    }

    .scroll-indicator {
        display: none;
    }
}






/* =========================
   SERVICES SECTION
========================= */

.services-section {
    position: relative;

    padding: 120px 0;

    background:
        linear-gradient(
            180deg,
            #050b18 0%,
            #07101f 50%,
            #050b18 100%
        );

    overflow: hidden;
}


/* Background Glow */

.services-section::before {
    content: "";

    position: absolute;

    width: 500px;
    height: 500px;

    top: 150px;
    left: -300px;

    border-radius: 50%;

    background: rgba(22, 119, 255, 0.06);

    filter: blur(100px);

    pointer-events: none;
}


/* =========================
   SECTION HEADER
========================= */

.section-header {
    max-width: 700px;

    margin: 0 auto 65px;

    text-align: center;
}

.section-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 7px 13px;

    margin-bottom: 18px;

    color: #70aeea;

    background: rgba(22, 119, 255, 0.07);

    border: 1px solid rgba(56, 163, 255, 0.15);

    border-radius: 50px;

    font-size: 11px;
    font-weight: 600;

    text-transform: uppercase;
    letter-spacing: 1px;
}

.section-badge span {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #1677ff;

    box-shadow: 0 0 10px #1677ff;
}


.section-header h2 {
    margin: 0;

    color: #ffffff;

    font-size: clamp(36px, 4vw, 52px);

    line-height: 1.1;

    letter-spacing: -1.8px;

    font-weight: 800;
}

.section-header h2 span {
    display: block;

    color: #3b9cff;
}


.section-header p {
    max-width: 620px;

    margin: 20px auto 0;

    color: #879bb6;

    font-size: 15px;

    line-height: 1.8;
}


/* =========================
   SERVICES GRID
========================= */

.services-grid {
    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}


/* =========================
   SERVICE CARD
========================= */

.service-card {
    position: relative;

    min-height: 430px;

    display: flex;
    flex-direction: column;

    padding: 27px;

    background:
        linear-gradient(
            145deg,
            rgba(16, 31, 57, 0.85),
            rgba(9, 19, 37, 0.9)
        );

    border: 1px solid rgba(255, 255, 255, 0.065);

    border-radius: 16px;

    overflow: hidden;

    transition:
        transform 0.35s ease,
        border-color 0.35s ease,
        box-shadow 0.35s ease;
}


/* Blue hover glow */

.service-card::before {
    content: "";

    position: absolute;

    width: 180px;
    height: 180px;

    top: -100px;
    right: -100px;

    border-radius: 50%;

    background: rgba(22, 119, 255, 0.15);

    filter: blur(50px);

    opacity: 0;

    transition: opacity 0.35s ease;
}


.service-card:hover {
    transform: translateY(-7px);

    border-color:
        rgba(56, 163, 255, 0.25);

    box-shadow:
        0 20px 50px rgba(0, 0, 0, 0.25),
        0 0 35px rgba(22, 119, 255, 0.05);
}

.service-card:hover::before {
    opacity: 1;
}


/* =========================
   CARD TOP
========================= */

.service-top {
    position: relative;
    z-index: 2;

    display: flex;
    align-items: center;
    justify-content: space-between;
}


.service-number {
    color: #3b506c;

    font-family:
        "Courier New",
        monospace;

    font-size: 12px;

    font-weight: 600;

    letter-spacing: 1px;
}


.service-icon {
    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background:
        linear-gradient(
            145deg,
            rgba(22, 119, 255, 0.14),
            rgba(22, 119, 255, 0.04)
        );

    border: 1px solid
        rgba(56, 163, 255, 0.12);

    border-radius: 12px;

    font-size: 14px;
    font-weight: 700;

    transition:
        background 0.3s ease,
        transform 0.3s ease;
}


.service-card:hover .service-icon {
    background: rgba(22, 119, 255, 0.2);

    transform: scale(1.05);
}


/* =========================
   CARD CONTENT
========================= */

.service-content {
    position: relative;
    z-index: 2;

    flex: 1;

    padding-top: 35px;
}


.service-content h3 {
    margin: 0 0 13px;

    color: #ffffff;

    font-size: 20px;

    line-height: 1.3;

    letter-spacing: -0.3px;
}


.service-content p {
    margin: 0;

    color: #8194af;

    font-size: 13px;

    line-height: 1.75;
}


/* =========================
   SERVICE FEATURES
========================= */

.service-features {
    display: flex;
    flex-direction: column;
    gap: 9px;

    margin: 25px 0 0;
    padding: 0;

    list-style: none;
}


.service-features li {
    position: relative;

    padding-left: 18px;

    color: #a7b8ce;

    font-size: 11px;
}


.service-features li::before {
    content: "";

    position: absolute;

    left: 0;
    top: 6px;

    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #1677ff;

    box-shadow:
        0 0 8px rgba(22, 119, 255, 0.7);
}


/* =========================
   SERVICE LINK
========================= */

.service-link {
    position: relative;
    z-index: 2;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding-top: 20px;

    color: #4da3ff;

    border-top: 1px solid
        rgba(255, 255, 255, 0.06);

    text-decoration: none;

    font-size: 12px;
    font-weight: 600;

    transition: color 0.3s ease;
}


.service-link span {
    font-size: 16px;

    transition:
        transform 0.3s ease;
}


.service-link:hover {
    color: #ffffff;
}


.service-link:hover span {
    transform: translate(3px, -3px);
}


/* =========================
   SERVICES CTA
========================= */

.services-cta {
    margin-top: 25px;

    padding: 25px 28px;

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 25px;

    background:
        linear-gradient(
            100deg,
            rgba(22, 119, 255, 0.11),
            rgba(16, 31, 57, 0.65)
        );

    border: 1px solid
        rgba(56, 163, 255, 0.12);

    border-radius: 16px;
}


.services-cta-content {
    display: flex;
    align-items: center;
    gap: 17px;
}


.cta-icon {
    width: 43px;
    height: 43px;

    flex-shrink: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    color: #ffffff;

    background: #1677ff;

    border-radius: 10px;

    font-size: 22px;

    box-shadow:
        0 8px 25px rgba(22, 119, 255, 0.25);
}


.services-cta h3 {
    margin: 0 0 5px;

    color: #ffffff;

    font-size: 15px;
}


.services-cta p {
    margin: 0;

    color: #7185a1;

    font-size: 11px;
}


.services-cta-button {
    display: inline-flex;
    align-items: center;
    gap: 9px;

    flex-shrink: 0;

    padding: 12px 17px;

    color: #ffffff;

    background: rgba(255, 255, 255, 0.05);

    border: 1px solid
        rgba(255, 255, 255, 0.1);

    border-radius: 8px;

    text-decoration: none;

    font-size: 12px;
    font-weight: 600;

    transition:
        background 0.3s ease,
        transform 0.3s ease;
}


.services-cta-button:hover {
    background: #1677ff;

    transform: translateY(-2px);
}


.services-cta-button span {
    font-size: 15px;
}


/* =========================
   TABLET
========================= */

@media (max-width: 1000px) {

    .services-grid {
        grid-template-columns:
            repeat(2, 1fr);
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 650px) {

    .services-section {
        padding: 85px 0;
    }

    .section-header {
        margin-bottom: 45px;
    }

    .section-header h2 {
        font-size: 36px;
    }

    .section-header p {
        font-size: 14px;
    }

    .services-grid {
        grid-template-columns: 1fr;

        gap: 14px;
    }

    .service-card {
        min-height: 400px;

        padding: 23px;
    }

    .services-cta {
        flex-direction: column;

        align-items: flex-start;
    }

    .services-cta-content {
        align-items: flex-start;
    }

    .services-cta-button {
        width: 100%;

        justify-content: center;
    }

}









/* =========================
   ABOUT SECTION
========================= */

.about-section {
    position: relative;

    padding: 120px 0;

    background: #050b18;

    overflow: hidden;
}


/* Background glow */

.about-section::before {
    content: "";

    position: absolute;

    width: 600px;
    height: 600px;

    right: -300px;
    top: 50px;

    border-radius: 50%;

    background: rgba(22, 119, 255, 0.06);

    filter: blur(110px);

    pointer-events: none;
}


/* =========================
   MAIN GRID
========================= */

.about-grid {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        1fr 1fr;

    align-items: center;

    gap: 90px;
}


/* =========================
   CONTENT
========================= */

.about-content {
    max-width: 580px;
}


.about-content .section-badge {
    margin-bottom: 20px;
}


.about-content h2 {
    margin: 0;

    color: #ffffff;

    font-size: clamp(40px, 4vw, 56px);

    line-height: 1.08;

    letter-spacing: -2px;

    font-weight: 800;
}


.about-content h2 span {
    display: block;

    color: #3d9dff;
}


.about-lead {
    margin: 28px 0 17px;

    color: #c3d0e2;

    font-size: 17px;

    line-height: 1.7;

    font-weight: 500;
}


.about-text {
    margin: 0;

    color: #7f93ae;

    font-size: 14px;

    line-height: 1.9;
}


/* =========================
   BUTTONS
========================= */

.about-buttons {
    display: flex;

    align-items: center;

    gap: 12px;

    margin-top: 32px;
}


.about-btn {
    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 9px;

    min-height: 46px;

    padding: 0 18px;

    border-radius: 8px;

    text-decoration: none;

    font-size: 12px;

    font-weight: 600;

    transition:
        transform 0.3s ease,
        background 0.3s ease,
        box-shadow 0.3s ease;
}


.about-btn.primary {
    color: #ffffff;

    background: #1677ff;

    box-shadow:
        0 8px 25px rgba(22, 119, 255, 0.18);
}


.about-btn.primary:hover {
    background: #0868e8;

    transform: translateY(-2px);

    box-shadow:
        0 12px 30px rgba(22, 119, 255, 0.3);
}


.about-btn.secondary {
    color: #aebed2;

    background: rgba(255, 255, 255, 0.035);

    border: 1px solid
        rgba(255, 255, 255, 0.08);
}


.about-btn.secondary:hover {
    color: #ffffff;

    background: rgba(255, 255, 255, 0.07);

    transform: translateY(-2px);
}


/* =========================
   ABOUT VISUAL
========================= */

.about-visual {
    position: relative;

    min-height: 510px;

    display: flex;

    align-items: center;

    justify-content: center;
}


/* =========================
   MAIN CARD
========================= */

.about-main-card {
    position: relative;

    z-index: 3;

    width: min(450px, 90%);

    padding: 25px;

    background:
        linear-gradient(
            145deg,
            rgba(17, 34, 63, 0.95),
            rgba(7, 17, 34, 0.96)
        );

    border: 1px solid
        rgba(56, 163, 255, 0.13);

    border-radius: 18px;

    box-shadow:
        0 30px 70px rgba(0, 0, 0, 0.4),
        0 0 50px rgba(22, 119, 255, 0.06);

    backdrop-filter: blur(20px);

    animation:
        aboutFloat 6s ease-in-out infinite;
}


/* =========================
   CARD HEADER
========================= */

.about-card-header {
    display: flex;

    align-items: center;

    gap: 13px;

    padding-bottom: 22px;

    border-bottom: 1px solid
        rgba(255, 255, 255, 0.06);
}


.about-logo {
    width: 43px;
    height: 43px;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #1677ff,
            #38a3ff
        );

    border-radius: 11px;

    font-size: 15px;

    font-weight: 800;

    box-shadow:
        0 8px 25px
        rgba(22, 119, 255, 0.2);
}


.about-card-header div:last-child {
    display: flex;

    flex-direction: column;

    gap: 4px;
}


.about-card-label {
    color: #4da3ff;

    font-size: 9px;

    font-weight: 700;

    letter-spacing: 1.5px;
}


.about-card-header strong {
    color: #ffffff;

    font-size: 13px;
}


/* =========================
   SOLUTION FLOW
========================= */

.solution-flow {
    padding: 28px 5px;
}


.solution-item {
    display: flex;

    align-items: center;

    gap: 13px;
}


.solution-icon {
    width: 38px;
    height: 38px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background:
        rgba(22, 119, 255, 0.08);

    border: 1px solid
        rgba(56, 163, 255, 0.1);

    border-radius: 9px;

    font-size: 12px;

    font-weight: 700;
}


.solution-item div:last-child {
    display: flex;

    flex-direction: column;

    gap: 3px;
}


.solution-item strong {
    color: #ffffff;

    font-size: 12px;
}


.solution-item span {
    color: #687d99;

    font-size: 10px;
}


.solution-line {
    width: 1px;

    height: 28px;

    margin-left: 19px;

    background:
        linear-gradient(
            to bottom,
            rgba(56, 163, 255, 0.35),
            rgba(56, 163, 255, 0.02)
        );
}


/* =========================
   CARD FOOTER
========================= */

.about-card-footer {
    display: flex;

    align-items: center;

    justify-content: space-between;

    padding-top: 17px;

    border-top: 1px solid
        rgba(255, 255, 255, 0.06);

    color: #70839e;

    font-size: 9px;

    font-weight: 600;

    letter-spacing: 0.5px;
}


.about-card-footer span:first-child {
    display: flex;

    align-items: center;

    gap: 7px;
}


.about-card-footer i {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #27e28b;

    box-shadow:
        0 0 8px #27e28b;
}


/* =========================
   FLOATING STATS
========================= */

.about-stat {
    position: absolute;

    z-index: 5;

    display: flex;

    flex-direction: column;

    gap: 3px;

    padding: 13px 16px;

    background:
        rgba(12, 27, 51, 0.92);

    border: 1px solid
        rgba(255, 255, 255, 0.08);

    border-radius: 11px;

    box-shadow:
        0 15px 35px
        rgba(0, 0, 0, 0.3);

    backdrop-filter: blur(12px);
}


.about-stat strong {
    color: #ffffff;

    font-size: 17px;
}


.about-stat span {
    color: #7185a1;

    font-size: 9px;
}


.stat-one {
    top: 70px;

    left: 0;
}


.stat-two {
    right: 0;

    bottom: 75px;
}


/* =========================
   DECORATIVE CIRCLE
========================= */

.about-circle {
    position: absolute;

    width: 430px;
    height: 430px;

    border: 1px solid
        rgba(56, 163, 255, 0.07);

    border-radius: 50%;

    transform: rotate(25deg);
}


/* =========================
   VALUES
========================= */

.about-values {
    position: relative;

    z-index: 2;

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 15px;

    margin-top: 90px;
}


.value-card {
    display: flex;

    align-items: flex-start;

    gap: 15px;

    padding: 22px;

    background:
        rgba(13, 27, 51, 0.55);

    border: 1px solid
        rgba(255, 255, 255, 0.055);

    border-radius: 13px;

    transition:
        transform 0.3s ease,
        border-color 0.3s ease;
}


.value-card:hover {
    transform: translateY(-4px);

    border-color:
        rgba(56, 163, 255, 0.18);
}


.value-icon {
    width: 38px;
    height: 38px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background:
        rgba(22, 119, 255, 0.09);

    border-radius: 9px;

    font-size: 14px;
}


.value-card h3 {
    margin: 1px 0 6px;

    color: #ffffff;

    font-size: 13px;
}


.value-card p {
    margin: 0;

    color: #7185a1;

    font-size: 10px;

    line-height: 1.7;
}


/* =========================
   ANIMATION
========================= */

@keyframes aboutFloat {

    0%,
    100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-8px);
    }

}


/* =========================
   TABLET
========================= */

@media (max-width: 950px) {

    .about-grid {
        grid-template-columns: 1fr;

        gap: 50px;
    }

    .about-content {
        max-width: 700px;

        margin: 0 auto;

        text-align: center;
    }

    .about-buttons {
        justify-content: center;
    }

    .about-visual {
        min-height: 480px;
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 650px) {

    .about-section {
        padding: 85px 0;
    }

    .about-content h2 {
        font-size: 38px;
    }

    .about-lead {
        font-size: 15px;
    }

    .about-text {
        font-size: 13px;
    }

    .about-buttons {
        flex-direction: column;

        width: 100%;
    }

    .about-btn {
        width: 100%;
    }

    .about-visual {
        min-height: 430px;
    }

    .about-main-card {
        width: 100%;

        padding: 20px;
    }

    .stat-one {
        left: -5px;
        top: 35px;
    }

    .stat-two {
        right: -5px;
        bottom: 35px;
    }

    .about-values {
        grid-template-columns: 1fr;

        margin-top: 60px;
    }

}









/* =========================
   FOUNDER SECTION
========================= */

.founder-section {
    position: relative;

    padding: 120px 0;

    background:
        linear-gradient(
            180deg,
            #050b18 0%,
            #07101f 50%,
            #050b18 100%
        );

    overflow: hidden;
}


/* Background glow */

.founder-section::before {
    content: "";

    position: absolute;

    width: 550px;
    height: 550px;

    left: -280px;
    top: 250px;

    border-radius: 50%;

    background:
        rgba(22, 119, 255, 0.06);

    filter: blur(110px);

    pointer-events: none;
}


/* =========================
   HEADER
========================= */

.founder-header {
    position: relative;
    z-index: 2;

    margin-bottom: 65px;
}


/* =========================
   FOUNDER CARD
========================= */

.founder-card {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        0.85fr 1.15fr;

    align-items: center;

    gap: 75px;

    padding: 45px;

    background:
        linear-gradient(
            135deg,
            rgba(16, 32, 59, 0.85),
            rgba(7, 17, 34, 0.9)
        );

    border: 1px solid
        rgba(255, 255, 255, 0.07);

    border-radius: 22px;

    box-shadow:
        0 30px 80px rgba(0, 0, 0, 0.25);
}


/* =========================
   IMAGE AREA
========================= */

.founder-image-area {
    position: relative;

    min-height: 450px;

    display: flex;

    align-items: center;
    justify-content: center;
}


.founder-image-frame {
    position: relative;

    z-index: 3;

    width: min(360px, 90%);

    aspect-ratio: 4 / 5;

    overflow: hidden;

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            #102747,
            #081326
        );

    border: 1px solid
        rgba(56, 163, 255, 0.16);

    box-shadow:
        0 30px 60px rgba(0, 0, 0, 0.4);
}


.founder-image-frame img {
    width: 100%;
    height: 100%;

    display: block;

    object-fit: cover;

    filter:
        saturate(0.9)
        contrast(1.05);

    transition:
        transform 0.5s ease;
}


.founder-image-frame:hover img {
    transform: scale(1.04);
}


/* Image overlay */

.founder-image-overlay {
    position: absolute;

    inset: 0;

    background:
        linear-gradient(
            to top,
            rgba(5, 11, 24, 0.65),
            transparent 45%
        );

    pointer-events: none;
}


/* Image label */

.founder-image-label {
    position: absolute;

    left: 18px;
    bottom: 18px;

    display: flex;

    align-items: center;

    gap: 9px;

    padding: 9px 13px;

    color: #d5e3f5;

    background:
        rgba(5, 11, 24, 0.8);

    border: 1px solid
        rgba(255, 255, 255, 0.08);

    border-radius: 8px;

    backdrop-filter: blur(10px);

    font-size: 10px;

    font-weight: 600;
}


/* =========================
   DECORATIVE ORBITS
========================= */

.founder-orbit {
    position: absolute;

    border: 1px solid
        rgba(56, 163, 255, 0.08);

    border-radius: 50%;

    pointer-events: none;
}


.orbit-founder-one {
    width: 430px;
    height: 430px;

    transform: rotate(25deg);
}


.orbit-founder-two {
    width: 330px;
    height: 500px;

    transform: rotate(-25deg);
}


/* =========================
   FOUNDER CONTENT
========================= */

.founder-content {
    max-width: 600px;
}


.founder-role {
    display: inline-block;

    margin-bottom: 12px;

    color: #4da3ff;

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 1.5px;

    text-transform: uppercase;
}


.founder-content h3 {
    margin: 0;

    color: #ffffff;

    font-size: clamp(36px, 4vw, 52px);

    line-height: 1.1;

    letter-spacing: -1.5px;

    font-weight: 800;
}


.founder-line {
    width: 55px;
    height: 3px;

    margin: 22px 0;

    background:
        linear-gradient(
            90deg,
            #1677ff,
            #38a3ff
        );

    border-radius: 10px;
}


.founder-intro {
    margin: 0 0 15px;

    color: #c5d2e4;

    font-size: 17px;

    line-height: 1.7;

    font-weight: 500;
}


.founder-description {
    margin: 0;

    color: #7e92ae;

    font-size: 14px;

    line-height: 1.9;
}


/* =========================
   EXPERTISE
========================= */

.founder-expertise {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 10px;

    margin-top: 30px;
}


.expertise-item {
    display: flex;

    align-items: center;

    gap: 11px;

    padding: 12px;

    background:
        rgba(255, 255, 255, 0.025);

    border: 1px solid
        rgba(255, 255, 255, 0.055);

    border-radius: 9px;

    transition:
        background 0.3s ease,
        border-color 0.3s ease;
}


.expertise-item:hover {
    background:
        rgba(22, 119, 255, 0.06);

    border-color:
        rgba(56, 163, 255, 0.15);
}


.expertise-icon {
    width: 32px;
    height: 32px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background:
        rgba(22, 119, 255, 0.09);

    border-radius: 7px;

    font-size: 11px;

    font-weight: 700;
}


.expertise-item div {
    display: flex;

    flex-direction: column;

    gap: 2px;
}


.expertise-item strong {
    color: #dbe7f7;

    font-size: 11px;
}


.expertise-item small {
    color: #647995;

    font-size: 9px;
}


/* =========================
   QUOTE
========================= */

.founder-quote {
    position: relative;

    display: flex;

    align-items: flex-start;

    gap: 10px;

    margin-top: 30px;

    padding: 17px 18px;

    background:
        linear-gradient(
            90deg,
            rgba(22, 119, 255, 0.07),
            rgba(22, 119, 255, 0.015)
        );

    border-left: 2px solid #1677ff;

    border-radius: 0 9px 9px 0;
}


.quote-mark {
    color: #1677ff;

    font-family: Georgia, serif;

    font-size: 28px;

    line-height: 20px;
}


.founder-quote p {
    margin: 0;

    color: #a9bad0;

    font-size: 12px;

    line-height: 1.7;

    font-style: italic;
}


/* =========================
   BOTTOM MESSAGE
========================= */

.founder-bottom {
    position: relative;
    z-index: 2;

    display: flex;

    align-items: center;

    gap: 14px;

    margin-top: 20px;

    padding: 20px 25px;

    background:
        rgba(13, 27, 51, 0.5);

    border: 1px solid
        rgba(255, 255, 255, 0.05);

    border-radius: 13px;
}


.founder-bottom-icon {
    width: 38px;
    height: 38px;

    display: flex;

    align-items: center;
    justify-content: center;

    flex-shrink: 0;

    color: #27e28b;

    background:
        rgba(39, 226, 139, 0.07);

    border: 1px solid
        rgba(39, 226, 139, 0.12);

    border-radius: 9px;
}


.founder-bottom div:last-child {
    display: flex;

    flex-direction: column;

    gap: 3px;
}


.founder-bottom strong {
    color: #ffffff;

    font-size: 12px;
}


.founder-bottom span {
    color: #687d99;

    font-size: 10px;
}


/* =========================
   TABLET
========================= */

@media (max-width: 950px) {

    .founder-card {
        grid-template-columns: 1fr;

        gap: 45px;

        padding: 35px;
    }

    .founder-image-area {
        min-height: 430px;
    }

    .founder-content {
        max-width: 700px;

        margin: 0 auto;

        text-align: center;
    }

    .founder-line {
        margin-left: auto;
        margin-right: auto;
    }

    .founder-quote {
        text-align: left;
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 650px) {

    .founder-section {
        padding: 85px 0;
    }

    .founder-card {
        padding: 22px;

        border-radius: 16px;
    }

    .founder-image-area {
        min-height: 390px;
    }

    .founder-image-frame {
        width: 82%;
    }

    .founder-content h3 {
        font-size: 38px;
    }

    .founder-intro {
        font-size: 15px;
    }

    .founder-description {
        font-size: 13px;
    }

    .founder-expertise {
        grid-template-columns: 1fr;
    }

    .founder-bottom {
        align-items: flex-start;

        padding: 17px;
    }

    .stat-one,
    .stat-two {
        display: none;
    }

}





/* =========================
   PAYMENT SECTION
========================= */

.payment-section {
    position: relative;

    padding: 120px 0;

    background: #050b18;

    overflow: hidden;
}


/* Background glow */

.payment-section::before {
    content: "";

    position: absolute;

    width: 600px;
    height: 600px;

    top: 50px;
    right: -350px;

    border-radius: 50%;

    background:
        rgba(22, 119, 255, 0.07);

    filter: blur(120px);

    pointer-events: none;
}


/* =========================
   HEADER
========================= */

.payment-header {
    position: relative;
    z-index: 2;

    margin-bottom: 60px;
}


/* =========================
   PAYMENT GRID
========================= */

.payment-grid {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;

    max-width: 900px;

    margin: 0 auto;
}


/* =========================
   PAYMENT CARD
========================= */

.payment-card {
    position: relative;

    padding: 30px;

    background:
        linear-gradient(
            145deg,
            rgba(16, 31, 57, 0.85),
            rgba(8, 18, 36, 0.95)
        );

    border: 1px solid
        rgba(255, 255, 255, 0.07);

    border-radius: 17px;

    overflow: hidden;

    transition:
        transform 0.3s ease,
        border-color 0.3s ease,
        box-shadow 0.3s ease;
}


.payment-card:hover {
    transform: translateY(-5px);

    border-color:
        rgba(56, 163, 255, 0.2);

    box-shadow:
        0 20px 50px
        rgba(0, 0, 0, 0.25);
}


/* Featured card */

.payment-card-featured {
    border-color:
        rgba(22, 119, 255, 0.2);

    background:
        linear-gradient(
            145deg,
            rgba(18, 44, 81, 0.9),
            rgba(8, 19, 38, 0.95)
        );
}


/* =========================
   CARD TOP
========================= */

.payment-card-top {
    display: flex;

    align-items: center;

    justify-content: space-between;
}


.currency-icon {
    width: 50px;
    height: 50px;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #1677ff,
            #38a3ff
        );

    border-radius: 12px;

    font-size: 17px;

    font-weight: 800;

    box-shadow:
        0 10px 25px
        rgba(22, 119, 255, 0.2);
}


.currency-code {
    color: #4da3ff;

    font-family:
        "Courier New",
        monospace;

    font-size: 13px;

    font-weight: 700;

    letter-spacing: 1px;
}


/* =========================
   CARD CONTENT
========================= */

.payment-card-content {
    padding: 30px 0;
}


.currency-label {
    color: #657a96;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1px;
}


.payment-card h3 {
    margin: 7px 0 12px;

    color: #ffffff;

    font-size: 24px;

    letter-spacing: -0.5px;
}


.payment-card p {
    margin: 0;

    color: #8194af;

    font-size: 13px;

    line-height: 1.8;
}


/* =========================
   STATUS
========================= */

.payment-status {
    display: flex;

    align-items: center;

    gap: 8px;

    padding-top: 15px;

    border-top: 1px solid
        rgba(255, 255, 255, 0.06);

    color: #8ea2bc;

    font-size: 10px;

    font-weight: 600;
}


.payment-status span {
    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #27e28b;

    box-shadow:
        0 0 10px rgba(39, 226, 139, 0.7);
}


/* =========================
   PAYMENT PROCESS
========================= */

.payment-process {
    position: relative;
    z-index: 2;

    max-width: 1050px;

    margin: 40px auto;

    padding: 23px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    background:
        rgba(13, 27, 51, 0.6);

    border: 1px solid
        rgba(255, 255, 255, 0.055);

    border-radius: 15px;
}


.process-item {
    display: flex;

    align-items: center;

    gap: 10px;
}


.process-number {
    width: 34px;
    height: 34px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #4da3ff;

    background:
        rgba(22, 119, 255, 0.08);

    border: 1px solid
        rgba(56, 163, 255, 0.12);

    border-radius: 8px;

    font-family:
        "Courier New",
        monospace;

    font-size: 9px;

    font-weight: 700;
}


.process-item div:last-child {
    display: flex;

    flex-direction: column;

    gap: 3px;
}


.process-item strong {
    color: #dce8f7;

    font-size: 11px;
}


.process-item span {
    color: #647995;

    font-size: 9px;
}


.process-line {
    width: 35px;
    height: 1px;

    background:
        rgba(56, 163, 255, 0.15);
}


/* =========================
   REFUND POLICY
========================= */

.refund-policy {
    position: relative;
    z-index: 2;

    display: flex;

    align-items: flex-start;

    gap: 18px;

    margin-top: 25px;

    padding: 25px;

    background:
        linear-gradient(
            100deg,
            rgba(255, 173, 51, 0.055),
            rgba(255, 255, 255, 0.018)
        );

    border: 1px solid
        rgba(255, 173, 51, 0.15);

    border-left: 3px solid #f5a623;

    border-radius: 13px;
}


/* Refund icon */

.refund-icon {
    width: 42px;
    height: 42px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #f5b84d;

    background:
        rgba(245, 166, 35, 0.09);

    border: 1px solid
        rgba(245, 166, 35, 0.15);

    border-radius: 9px;

    font-size: 18px;

    font-weight: 800;
}


/* Refund content */

.refund-content {
    flex: 1;
}


.refund-title {
    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 9px;
}


.refund-title span {
    color: #7f93ad;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1px;
}


.refund-title strong {
    color: #f5b84d;

    font-size: 14px;
}


.refund-content p {
    max-width: 850px;

    margin: 0;

    color: #8b9db5;

    font-size: 12px;

    line-height: 1.8;
}


.refund-content p strong {
    color: #e5edf8;
}


.refund-note {
    margin-top: 7px !important;

    color: #687d99 !important;

    font-size: 10px !important;
}


/* =========================
   CTA
========================= */

.payment-cta {
    position: relative;
    z-index: 2;

    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 20px;

    margin-top: 20px;

    padding: 23px 25px;

    background:
        linear-gradient(
            100deg,
            rgba(22, 119, 255, 0.09),
            rgba(13, 27, 51, 0.5)
        );

    border: 1px solid
        rgba(56, 163, 255, 0.09);

    border-radius: 13px;
}


.payment-cta div {
    display: flex;

    flex-direction: column;

    gap: 5px;
}


.payment-cta strong {
    color: #ffffff;

    font-size: 13px;
}


.payment-cta span {
    color: #7185a1;

    font-size: 10px;
}


.payment-cta-button {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    padding: 11px 17px;

    color: #ffffff;

    background: #1677ff;

    border-radius: 8px;

    text-decoration: none;

    font-size: 11px;

    font-weight: 600;

    transition:
        transform 0.3s ease,
        background 0.3s ease;
}


.payment-cta-button:hover {
    background: #0868e8;

    transform: translateY(-2px);
}


/* =========================
   TABLET
========================= */

@media (max-width: 850px) {

    .payment-process {
        display: grid;

        grid-template-columns:
            repeat(2, 1fr);

        gap: 20px;
    }

    .process-line {
        display: none;
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 650px) {

    .payment-section {
        padding: 85px 0;
    }

    .payment-grid {
        grid-template-columns: 1fr;
    }

    .payment-card {
        padding: 23px;
    }

    .payment-process {
        grid-template-columns: 1fr;

        padding: 18px;
    }

    .refund-policy {
        padding: 20px;

        gap: 13px;
    }

    .refund-title {
        flex-direction: column;

        align-items: flex-start;

        gap: 4px;
    }

    .payment-cta {
        flex-direction: column;

        align-items: flex-start;
    }

    .payment-cta-button {
        width: 100%;

        justify-content: center;
    }

}









/* =========================
   CONTACT SECTION
========================= */

.contact-section {
    position: relative;

    padding: 120px 0;

    background:
        linear-gradient(
            180deg,
            #050b18,
            #07101f
        );

    overflow: hidden;
}


/* Background glow */

.contact-section::before {
    content: "";

    position: absolute;

    width: 600px;
    height: 600px;

    left: 50%;
    top: 30%;

    transform: translateX(-50%);

    border-radius: 50%;

    background:
        rgba(22, 119, 255, 0.045);

    filter: blur(120px);

    pointer-events: none;
}


/* =========================
   HEADER
========================= */

.contact-header {
    position: relative;
    z-index: 2;

    margin-bottom: 60px;
}


/* =========================
   CONTACT GRID
========================= */

.contact-grid {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        1fr 0.9fr;

    gap: 25px;

    max-width: 1050px;

    margin: 0 auto;
}


/* =========================
   CONTACT INFO
========================= */

.contact-info {
    padding: 10px 0;
}


.contact-info-header {
    margin-bottom: 25px;
}


.contact-info-header > span {
    color: #4da3ff;

    font-size: 10px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 1.3px;
}


.contact-info-header h3 {
    margin: 8px 0 9px;

    color: #ffffff;

    font-size: 27px;

    letter-spacing: -0.7px;
}


.contact-info-header p {
    max-width: 480px;

    margin: 0;

    color: #7185a1;

    font-size: 12px;

    line-height: 1.8;
}


/* =========================
   CONTACT ITEM
========================= */

.contact-item {
    position: relative;

    display: flex;

    align-items: center;

    gap: 14px;

    padding: 18px;

    margin-bottom: 10px;

    color: inherit;

    text-decoration: none;

    background:
        rgba(13, 27, 51, 0.65);

    border: 1px solid
        rgba(255, 255, 255, 0.06);

    border-radius: 12px;

    transition:
        transform 0.3s ease,
        border-color 0.3s ease,
        background 0.3s ease;
}


.contact-item:hover {
    transform: translateX(5px);

    background:
        rgba(18, 42, 76, 0.7);

    border-color:
        rgba(56, 163, 255, 0.18);
}


/* Contact icon */

.contact-icon {
    width: 43px;
    height: 43px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #42a5ff;

    background:
        rgba(22, 119, 255, 0.09);

    border: 1px solid
        rgba(56, 163, 255, 0.1);

    border-radius: 10px;

    font-size: 15px;

    font-weight: 700;
}


.form-icon {
    color: #27e28b;

    background:
        rgba(39, 226, 139, 0.07);

    border-color:
        rgba(39, 226, 139, 0.12);
}


/* Contact text */

.contact-item-content {
    display: flex;

    flex-direction: column;

    gap: 3px;

    min-width: 0;
}


.contact-item-content span {
    color: #627792;

    font-size: 9px;

    text-transform: uppercase;

    letter-spacing: 1px;
}


.contact-item-content strong {
    color: #dce7f5;

    font-size: 13px;

    overflow-wrap: anywhere;
}


.contact-item-content small {
    color: #647995;

    font-size: 9px;
}


/* Arrow */

.contact-arrow {
    margin-left: auto;

    color: #4d6888;

    font-size: 17px;

    transition:
        color 0.3s ease,
        transform 0.3s ease;
}


.contact-item:hover .contact-arrow {
    color: #42a5ff;

    transform: translate(2px, -2px);
}


/* =========================
   CONTACT CARD
========================= */

.contact-card {
    position: relative;

    min-height: 480px;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 40px;

    background:
        linear-gradient(
            145deg,
            #0c2342,
            #071426
        );

    border: 1px solid
        rgba(56, 163, 255, 0.14);

    border-radius: 20px;

    overflow: hidden;

    box-shadow:
        0 30px 70px rgba(0, 0, 0, 0.3);
}


/* Card glow */

.contact-card-glow {
    position: absolute;

    width: 250px;
    height: 250px;

    right: -100px;
    top: -100px;

    border-radius: 50%;

    background:
        rgba(22, 119, 255, 0.18);

    filter: blur(60px);

    pointer-events: none;
}


.contact-card-content {
    position: relative;

    z-index: 2;

    width: 100%;

    text-align: center;
}


/* Card icon */

.contact-card-icon {
    width: 60px;
    height: 60px;

    display: flex;

    align-items: center;
    justify-content: center;

    margin: 0 auto 18px;

    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #1677ff,
            #38a3ff
        );

    border-radius: 15px;

    font-size: 18px;

    font-weight: 800;

    box-shadow:
        0 12px 30px
        rgba(22, 119, 255, 0.25);
}


.contact-card-label {
    color: #4da3ff;

    font-size: 9px;

    font-weight: 700;

    letter-spacing: 2px;
}


.contact-card h3 {
    max-width: 380px;

    margin: 13px auto 15px;

    color: #ffffff;

    font-size: 31px;

    line-height: 1.15;

    letter-spacing: -1px;
}


.contact-card h3 span {
    color: #3d9dff;
}


.contact-card-content > p {
    max-width: 390px;

    margin: 0 auto;

    color: #8195b0;

    font-size: 12px;

    line-height: 1.8;
}


/* =========================
   AVAILABILITY
========================= */

.availability {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    margin: 25px auto;

    padding: 12px;

    max-width: 260px;

    background:
        rgba(39, 226, 139, 0.04);

    border: 1px solid
        rgba(39, 226, 139, 0.09);

    border-radius: 9px;

    text-align: left;
}


.availability-dot {
    width: 8px;
    height: 8px;

    flex-shrink: 0;

    border-radius: 50%;

    background: #27e28b;

    box-shadow:
        0 0 10px #27e28b;
}


.availability div {
    display: flex;

    flex-direction: column;

    gap: 2px;
}


.availability strong {
    color: #bdebd3;

    font-size: 10px;
}


.availability small {
    color: #648073;

    font-size: 8px;
}


/* =========================
   MAIN BUTTON
========================= */

.contact-main-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    gap: 10px;

    width: 100%;

    max-width: 300px;

    min-height: 48px;

    padding: 0 18px;

    color: #ffffff;

    background: #1677ff;

    border-radius: 8px;

    text-decoration: none;

    font-size: 11px;

    font-weight: 700;

    box-shadow:
        0 10px 30px
        rgba(22, 119, 255, 0.2);

    transition:
        transform 0.3s ease,
        background 0.3s ease,
        box-shadow 0.3s ease;
}


.contact-main-button:hover {
    background: #0868e8;

    transform: translateY(-2px);

    box-shadow:
        0 15px 35px
        rgba(22, 119, 255, 0.3);
}


.contact-main-button span {
    font-size: 16px;
}


.contact-response {
    display: block;

    margin-top: 12px;

    color: #586d89;

    font-size: 9px;
}


/* =========================
   BOTTOM STRIP
========================= */

.contact-bottom {
    position: relative;
    z-index: 2;

    max-width: 1050px;

    margin: 20px auto 0;

    padding: 20px 25px;

    display: flex;

    align-items: center;

    justify-content: space-around;

    background:
        rgba(13, 27, 51, 0.55);

    border: 1px solid
        rgba(255, 255, 255, 0.05);

    border-radius: 12px;
}


.contact-bottom > div:not(.bottom-divider) {
    display: flex;

    align-items: center;

    gap: 10px;
}


.bottom-label {
    color: #536984;

    font-size: 8px;

    font-weight: 700;

    letter-spacing: 1px;
}


.contact-bottom strong {
    color: #d9e5f4;

    font-size: 11px;
}


.bottom-divider {
    width: 1px;
    height: 20px;

    background:
        rgba(255, 255, 255, 0.08);
}


/* =========================
   TABLET
========================= */

@media (max-width: 850px) {

    .contact-grid {
        grid-template-columns: 1fr;
    }

    .contact-card {
        min-height: 430px;
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 650px) {

    .contact-section {
        padding: 85px 0;
    }

    .contact-grid {
        gap: 18px;
    }

    .contact-item {
        padding: 15px;
    }

    .contact-item-content strong {
        font-size: 12px;
    }

    .contact-card {
        min-height: 430px;

        padding: 28px 20px;
    }

    .contact-card h3 {
        font-size: 27px;
    }

    .contact-bottom {
        flex-direction: column;

        align-items: stretch;

        gap: 15px;

        padding: 18px;
    }

    .contact-bottom > div:not(.bottom-divider) {
        justify-content: space-between;
    }

    .bottom-divider {
        width: 100%;
        height: 1px;
    }

}





/* =========================
   FOOTER
========================= */

.site-footer {
    position: relative;

    padding: 75px 0 0;

    background:
        linear-gradient(
            180deg,
            #07101f 0%,
            #030812 100%
        );

    border-top: 1px solid
        rgba(255, 255, 255, 0.06);

    overflow: hidden;
}


/* Top blue glow */

.site-footer::before {
    content: "";

    position: absolute;

    width: 500px;
    height: 180px;

    left: 50%;
    top: -150px;

    transform: translateX(-50%);

    background:
        rgba(22, 119, 255, 0.13);

    filter: blur(80px);

    pointer-events: none;
}


/* =========================
   FOOTER MAIN
========================= */

.footer-main {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        1.5fr 0.8fr 1.15fr 1.1fr;

    gap: 55px;

    padding-bottom: 55px;

    border-bottom: 1px solid
        rgba(255, 255, 255, 0.055);
}


/* =========================
   BRAND
========================= */

.footer-brand {
    max-width: 330px;
}


.footer-logo {
    display: inline-flex;

    align-items: center;

    gap: 10px;

    color: #ffffff;

    text-decoration: none;

    font-size: 18px;

    font-weight: 800;

    letter-spacing: -0.5px;
}


.footer-logo > span:last-child span {
    color: #3d9dff;
}


.footer-logo-icon {
    width: 37px;
    height: 37px;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #1677ff,
            #38a3ff
        );

    border-radius: 9px;

    font-size: 12px;

    font-weight: 800;

    box-shadow:
        0 8px 25px
        rgba(22, 119, 255, 0.2);
}


.footer-brand p {
    margin: 20px 0;

    color: #687c98;

    font-size: 11px;

    line-height: 1.9;
}


.footer-availability {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    color: #8fa5bd;

    font-size: 10px;

    font-weight: 600;
}


.footer-availability span {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #27e28b;

    box-shadow:
        0 0 9px #27e28b;
}


/* =========================
   FOOTER COLUMNS
========================= */

.footer-column h3 {
    margin: 2px 0 19px;

    color: #ffffff;

    font-size: 12px;

    font-weight: 700;
}


.footer-column ul {
    display: flex;

    flex-direction: column;

    gap: 10px;

    margin: 0;
    padding: 0;

    list-style: none;
}


.footer-column li a {
    color: #6f839e;

    text-decoration: none;

    font-size: 10px;

    transition:
        color 0.25s ease,
        transform 0.25s ease;
}


.footer-column li a:hover {
    color: #4da3ff;

    transform: translateX(3px);
}


/* =========================
   CONTACT
========================= */

.footer-contact {
    display: flex;

    flex-direction: column;
}


.footer-contact > a {
    display: flex;

    align-items: center;

    gap: 9px;

    margin-bottom: 11px;

    color: #7185a0;

    text-decoration: none;

    font-size: 10px;

    overflow-wrap: anywhere;

    transition:
        color 0.25s ease;
}


.footer-contact > a:hover {
    color: #ffffff;
}


.footer-contact-icon {
    width: 26px;
    height: 26px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #3f9eff;

    background:
        rgba(22, 119, 255, 0.08);

    border: 1px solid
        rgba(56, 163, 255, 0.08);

    border-radius: 6px;

    font-size: 9px;

    font-weight: 700;
}


/* =========================
   FOOTER HIGHLIGHTS
========================= */

.footer-highlight {
    position: relative;
    z-index: 2;

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 10px;

    padding: 25px 0;

    border-bottom: 1px solid
        rgba(255, 255, 255, 0.055);
}


.footer-highlight-item {
    display: flex;

    align-items: center;

    gap: 10px;

    padding: 13px;

    background:
        rgba(255, 255, 255, 0.018);

    border: 1px solid
        rgba(255, 255, 255, 0.035);

    border-radius: 8px;
}


.highlight-icon {
    width: 31px;
    height: 31px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #4da3ff;

    background:
        rgba(22, 119, 255, 0.08);

    border-radius: 7px;

    font-size: 10px;

    font-weight: 800;
}


.highlight-icon.green {
    color: #27e28b;

    background:
        rgba(39, 226, 139, 0.07);
}


.highlight-icon.warning {
    color: #f5b84d;

    background:
        rgba(245, 166, 35, 0.07);
}


.footer-highlight-item div {
    display: flex;

    flex-direction: column;

    gap: 3px;
}


.footer-highlight-item strong {
    color: #d8e4f2;

    font-size: 10px;
}


.footer-highlight-item small {
    color: #5f738e;

    font-size: 8px;
}


/* =========================
   FOOTER BOTTOM
========================= */

.footer-bottom {
    position: relative;
    z-index: 2;

    min-height: 70px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;
}


.footer-bottom p {
    margin: 0;

    color: #50647f;

    font-size: 9px;
}


.footer-legal {
    display: flex;

    align-items: center;

    gap: 10px;
}


.footer-legal a {
    color: #50647f;

    text-decoration: none;

    font-size: 9px;

    transition:
        color 0.25s ease;
}


.footer-legal a:hover {
    color: #4da3ff;
}


.footer-legal span {
    color: #2d405a;

    font-size: 9px;
}


/* =========================
   TABLET
========================= */

@media (max-width: 950px) {

    .footer-main {
        grid-template-columns:
            repeat(2, 1fr);

        gap: 40px;
    }

    .footer-brand {
        max-width: 400px;
    }

    .footer-highlight {
        grid-template-columns:
            repeat(2, 1fr);
    }

}


/* =========================
   MOBILE
========================= */

@media (max-width: 600px) {

    .site-footer {
        padding-top: 60px;
    }

    .footer-main {
        grid-template-columns: 1fr;

        gap: 35px;

        padding-bottom: 40px;
    }

    .footer-brand {
        max-width: 100%;
    }

    .footer-highlight {
        grid-template-columns: 1fr;

        padding: 20px 0;
    }

    .footer-bottom {
        min-height: 100px;

        flex-direction: column;

        justify-content: center;

        text-align: center;
    }

}

</style>

`
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.querySelector(".nav-links");
const navItems = document.querySelectorAll(".nav-link");

menuToggle.addEventListener("click", () => {

    const isOpen = navLinks.classList.toggle("active");

    menuToggle.setAttribute("aria-expanded", isOpen);

    menuToggle.classList.toggle("open", isOpen);
});


// Close mobile menu after clicking a link

navItems.forEach(link => {

    link.addEventListener("click", () => {

        navLinks.classList.remove("active");

        menuToggle.setAttribute("aria-expanded", "false");

    });

});





document.getElementById("currentYear").textContent =
        new Date().getFullYear();