# TechBuildZone
Official Site


<body>

    <header>
        <!-- Navigation -->
    </header>

    <main>

        <section id="home">
            <!-- Hero -->
        </section>

        <section id="services">
            <!-- Services -->
        </section>

        <section id="about">
            <!-- About TechCombinators -->
        </section>

        <section id="founder">
            <!-- Founder -->
        </section>

        <section id="why-us">
            <!-- Why Choose Us -->
        </section>

        <section id="payments">
            <!-- LKR / USD + No Refund Policy -->
        </section>

        <section id="contact">
            <!-- Mobile + Email + Google Form -->
        </section>

    </main>

    <footer>
        <!-- Footer -->
    </footer>

    <script src="js/script.js"></script>
</body>
